library(testthat)
library(williamsfinance)

test_check("williamsfinance")
